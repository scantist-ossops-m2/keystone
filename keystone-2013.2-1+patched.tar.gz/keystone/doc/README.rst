Building Docs
=============

Developer documentation is generated using Sphinx. To build this documentation,
run the following from the root of the repository::

  $ python setup.py build_sphinx

The documentation will be built at ``doc/build/``.
