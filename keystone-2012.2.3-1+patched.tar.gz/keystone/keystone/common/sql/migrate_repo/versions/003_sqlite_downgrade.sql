alter TABLE token  drop column valid;
